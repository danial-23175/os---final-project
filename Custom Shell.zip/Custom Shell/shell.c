#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>
#include "parser.h"
#include "executor.h"
#include "jobs.h"

#define PROMPT "myshell> "

volatile sig_atomic_t fg_pid = 0;

void sigint_handler(int signo) {
    if (fg_pid != 0) kill(fg_pid, SIGINT);
    printf("\n");
    fflush(stdout);
}

void sigtstp_handler(int signo) {
    if (fg_pid != 0) kill(fg_pid, SIGTSTP);
    printf("\n");
    fflush(stdout);
}

int main() {
    char *line;
    signal(SIGINT, sigint_handler);
    signal(SIGTSTP, sigtstp_handler);

    while (1) {
        printf("%s", PROMPT);
        line = NULL;
        size_t len = 0;
        if (getline(&line, &len, stdin) == -1) {
            printf("\n");
            free(line);
            break;
        }

        line[strcspn(line, "\n")] = 0; // remove newline

        if (line[0] == 0) { free(line); continue; }

        // Check for 'jobs' or 'fg' commands
        if (strcmp(line, "jobs") == 0) { list_jobs(); free(line); continue; }
        if (strncmp(line, "fg ", 3) == 0) {
            int id = atoi(line + 3);
            bring_job_foreground(id);
            free(line);
            continue;
        }

        int background = 0;
        if (line[strlen(line)-1] == '&') {
            background = 1;
            line[strlen(line)-1] = '\0'; // remove &
        }

        Command *cmd = parse_line(line);
        if (!cmd) { free(line); continue; }

        pid_t pid = fork();
        if (pid == 0) { // Child process
            fg_pid = getpid();
            execute_command(cmd);
            exit(0);
        } else if (pid > 0) { // Parent
            if (background) {
                add_job(pid, line, 1);
                printf("[%d] %d\n", job_count-1, pid);
            } else {
                fg_pid = pid;
                int status;
                waitpid(pid, &status, WUNTRACED);
                fg_pid = 0;
            }
        } else {
            perror("fork");
        }

        free_command(cmd);
        free(line);
    }
    return 0;
}
