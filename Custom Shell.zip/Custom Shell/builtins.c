#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "builtins.h"

int execute_builtin(Command *cmd) {
    if (strcmp(cmd->argv[0], "cd") == 0) {
        if (cmd->argc < 2) {
            fprintf(stderr, "cd: missing argument\n");
        } else {
            if (chdir(cmd->argv[1]) != 0) perror("cd");
        }
        return 1;
    } else if (strcmp(cmd->argv[0], "pwd") == 0) {
        char cwd[1024];
        if (getcwd(cwd, sizeof(cwd)) != NULL)
            printf("%s\n", cwd);
        return 1;
    } else if (strcmp(cmd->argv[0], "exit") == 0) {
        exit(0);
    } else if (strcmp(cmd->argv[0], "mkdir") == 0) {
        if (cmd->argc < 2) {
            fprintf(stderr, "mkdir: missing argument\n");
        } else {
            if (mkdir(cmd->argv[1], 0755) != 0) perror("mkdir");
        }
        return 1;
    } else if (strcmp(cmd->argv[0], "touch") == 0) {
        if (cmd->argc < 2) {
            fprintf(stderr, "touch: missing argument\n");
        } else {
            FILE *fp = fopen(cmd->argv[1], "a");
            if (!fp) perror("touch");
            else fclose(fp);
        }
        return 1;
    }
    return 0; // Not a built-in
}
