#ifndef JOBS_H
#define JOBS_H

#include <sys/types.h>

typedef struct Job {
    pid_t pid;
    char *cmdline;
    int id;
    int running; // 1 if running, 0 if stopped
    struct Job *next;
} Job;

void add_job(pid_t pid, char *cmdline, int running);
void remove_job(pid_t pid);
void list_jobs();
Job* find_job(int id);
void bring_job_foreground(int id);

#endif
