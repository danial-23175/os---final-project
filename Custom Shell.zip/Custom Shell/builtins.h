#ifndef BUILTINS_H
#define BUILTINS_H

#include "parser.h"

int execute_builtin(Command *cmd);

#endif
