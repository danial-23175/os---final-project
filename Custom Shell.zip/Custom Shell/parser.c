#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parser.h"
#include "utils.h"

#define TOKEN_BUF 64
#define DELIM " \t\r\n\a"

// Helper: split string into tokens respecting quotes
static char **tokenize(char *line, int *argc) {
    int bufsize = TOKEN_BUF;
    char **tokens = malloc(bufsize * sizeof(char*));
    char *token;
    int pos = 0;
    int in_quotes = 0;
    char quote_char = '\0';
    char *start = line;

    for (char *c = line; ; c++) {
        if (*c == '"' || *c == '\'') {
            if (!in_quotes) {
                in_quotes = 1;
                quote_char = *c;
                start = c + 1;
            } else if (*c == quote_char) {
                in_quotes = 0;
                *c = '\0';
                tokens[pos++] = strdup(start);
                start = c + 1;
            }
        } else if ((*c == ' ' || *c == '\t' || *c == '\0' || *c == '\n') && !in_quotes) {
            if (start != c) {
                *c = '\0';
                tokens[pos++] = strdup(start);
            }
            start = c + 1;
        }
        if (*c == '\0') break;
    }
    tokens[pos] = NULL;
    *argc = pos;
    return tokens;
}

Command* parse_line(char *line) {
    Command *head = NULL;
    Command *current = NULL;

    char *pipe_segment = strtok(line, "|");
    while (pipe_segment != NULL) {
        Command *cmd = malloc(sizeof(Command));
        cmd->argv = NULL;
        cmd->argc = 0;
        cmd->input_file = NULL;
        cmd->output_file = NULL;
        cmd->append_output = 0;
        cmd->next = NULL;

        int argc = 0;
        char **tokens = tokenize(pipe_segment, &argc);

        // Process redirection symbols
        int i = 0, j = 0;
        cmd->argv = malloc(sizeof(char*) * (argc + 1));
        for (i = 0; i < argc; i++) {
            if (strcmp(tokens[i], "<") == 0 && i + 1 < argc) {
                cmd->input_file = strdup(tokens[++i]);
            } else if (strcmp(tokens[i], ">") == 0 && i + 1 < argc) {
                cmd->output_file = strdup(tokens[++i]);
                cmd->append_output = 0;
            } else if (strcmp(tokens[i], ">>") == 0 && i + 1 < argc) {
                cmd->output_file = strdup(tokens[++i]);
                cmd->append_output = 1;
            } else {
                cmd->argv[j++] = strdup(tokens[i]);
            }
        }
        cmd->argv[j] = NULL;
        cmd->argc = j;

        // Append to linked list
        if (!head) {
            head = cmd;
            current = cmd;
        } else {
            current->next = cmd;
            current = cmd;
        }

        for (i = 0; i < argc; i++) free(tokens[i]);
        free(tokens);

        pipe_segment = strtok(NULL, "|");
    }

    return head;
}

void free_command(Command *cmd) {
    while (cmd) {
        Command *next = cmd->next;
        for (int i = 0; i < cmd->argc; i++)
            free(cmd->argv[i]);
        free(cmd->argv);
        if (cmd->input_file) free(cmd->input_file);
        if (cmd->output_file) free(cmd->output_file);
        free(cmd);
        cmd = next;
    }
}
