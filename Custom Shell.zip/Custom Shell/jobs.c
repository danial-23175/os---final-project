#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "jobs.h"

static Job *job_list = NULL;
static int job_count = 1;

void add_job(pid_t pid, char *cmdline, int running) {
    Job *job = malloc(sizeof(Job));
    job->pid = pid;
    job->cmdline = strdup(cmdline);
    job->id = job_count++;
    job->running = running;
    job->next = job_list;
    job_list = job;
}

void remove_job(pid_t pid) {
    Job *prev = NULL;
    Job *curr = job_list;
    while (curr) {
        if (curr->pid == pid) {
            if (prev) prev->next = curr->next;
            else job_list = curr->next;
            free(curr->cmdline);
            free(curr);
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}

void list_jobs() {
    Job *curr = job_list;
    while (curr) {
        printf("[%d] %s %s\n", curr->id, curr->running ? "Running" : "Stopped", curr->cmdline);
        curr = curr->next;
    }
}

Job* find_job(int id) {
    Job *curr = job_list;
    while (curr) {
        if (curr->id == id) return curr;
        curr = curr->next;
    }
    return NULL;
}

void bring_job_foreground(int id) {
    Job *job = find_job(id);
    if (!job) { printf("No such job\n"); return; }

    job->running = 1;
    int status;
    printf("%s\n", job->cmdline);
    waitpid(job->pid, &status, WUNTRACED);
    remove_job(job->pid);
}
