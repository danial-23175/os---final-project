#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "executor.h"
#include "builtins.h"

void execute_single(Command *cmd) {
    if (cmd->argc == 0) return;

    // Check for built-in commands
    if (execute_builtin(cmd)) return;

    pid_t pid = fork();
    if (pid == 0) {
        // Child process
        if (cmd->input_file) {
            int fd = open(cmd->input_file, O_RDONLY);
            if (fd < 0) { perror("open"); exit(1); }
            dup2(fd, STDIN_FILENO);
            close(fd);
        }
        if (cmd->output_file) {
            int fd;
            if (cmd->append_output)
                fd = open(cmd->output_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
            else
                fd = open(cmd->output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd < 0) { perror("open"); exit(1); }
            dup2(fd, STDOUT_FILENO);
            close(fd);
        }
        execvp(cmd->argv[0], cmd->argv);
        perror("exec");
        exit(1);
    } else if (pid > 0) {
        waitpid(pid, NULL, 0);
    } else {
        perror("fork");
    }
}

void execute_command(Command *cmd) {
    if (!cmd) return;

    // Handle piping
    if (!cmd->next) {
        execute_single(cmd);
        return;
    }

    int fd[2];
    if (pipe(fd) == -1) { perror("pipe"); return; }

    pid_t pid1 = fork();
    if (pid1 == 0) {
        close(fd[0]);
        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);
        execute_single(cmd);
        exit(0);
    }

    pid_t pid2 = fork();
    if (pid2 == 0) {
        close(fd[1]);
        dup2(fd[0], STDIN_FILENO);
        close(fd[0]);
        execute_command(cmd->next);
        exit(0);
    }

    close(fd[0]);
    close(fd[1]);
    waitpid(pid1, NULL, 0);
    waitpid(pid2, NULL, 0);
}
