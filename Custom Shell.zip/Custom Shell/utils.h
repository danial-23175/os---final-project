#ifndef UTILS_H
#define UTILS_H

char *trim_whitespace(char *str);

#endif
