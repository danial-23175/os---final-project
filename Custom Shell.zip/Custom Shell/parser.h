#ifndef PARSER_H
#define PARSER_H

typedef struct Command {
    char **argv;            // Arguments array
    int argc;               // Number of arguments
    char *input_file;       // Input redirection
    char *output_file;      // Output redirection
    int append_output;      // 1 if >>
    struct Command *next;   // For pipes
} Command;

Command* parse_line(char *line);
void free_command(Command *cmd);

#endif
